import matlab.engine
import os

# 启动Matlab引擎
eng = matlab.engine.start_matlab()

# 假设你的Matlab函数名为your_matlab_function，根据实际情况修改
eng.cd(r'/Users/zhouruichun/Downloads/carTrack',nargout=0)

# 文件夹路径，根据实际情况修改
folder_path = "/Users/zhouruichun/Downloads/detect 2/3840*2160"  

# 遍历文件夹下的所有txt文件
for file_name in os.listdir(folder_path):
    if file_name.endswith(".txt"):
        file_path = os.path.join(folder_path, file_name)
        with open(file_path, "r") as file:
            lines = file.readlines()
            new_lines = []
            for line in lines:
                parts = line.strip().split()
                x = float(parts[1])
                y = float(parts[2])
                # 调用Matlab函数，传入像素坐标，获取返回值（这里假设返回两个值，根据实际返回值数量和类型调整）
                result = eng.trackCarPoint(x, y, nargout=2)
                print(f"Function result: {result}") 
                if isinstance(result, (list, tuple)) and len(result) == 2:
                    new_line = f"{line.strip()} {result[0]} {result[1]}\n"
                    print(new_line)
                    new_lines.append(new_line)
            # 将更新后的内容写回原文件（注意备份原文件以防数据丢失）
            with open(file_path, "w") as output_file:
                output_file.writelines(new_lines)

# 关闭Matlab引擎
eng.quit()
